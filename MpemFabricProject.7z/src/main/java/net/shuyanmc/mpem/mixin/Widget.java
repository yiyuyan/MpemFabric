package net.shuyanmc.mpem.mixin;

public interface Widget {

}
