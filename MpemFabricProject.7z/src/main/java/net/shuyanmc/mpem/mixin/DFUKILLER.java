package net.shuyanmc.mpem.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;

import net.minecraft.SharedConstants;


@Mixin(value = SharedConstants.class)
public class DFUKILLER {
    /**
     * @author KSmc_brigade
     * @reason nothing
     */
    @Overwrite
    public static void enableDataFixerOptimization() {
        //no-code
    }
}