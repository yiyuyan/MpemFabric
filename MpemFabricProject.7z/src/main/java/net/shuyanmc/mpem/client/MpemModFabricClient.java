package net.shuyanmc.mpem.client;

import net.fabricmc.api.ClientModInitializer;

public class MpemModFabricClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
    }
}
