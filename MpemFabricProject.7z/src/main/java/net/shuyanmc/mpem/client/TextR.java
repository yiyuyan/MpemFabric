package net.shuyanmc.mpem.client;

import net.minecraft.text.Text;

public class TextR {
    public Text text;

    public TextR(net.minecraft.text.Text text){
        this.text = text;
    }
}
