package net.shuyanmc.mpem;

import java.util.concurrent.Executor;

public interface LazyDataFixerBuilderl {
    void build(Executor executor);
}
