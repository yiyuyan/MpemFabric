package net.shuyanmc.mpem;
public class flang {
    public static boolean langReload = false;
}
