package net.shuyanmc.mpem;

public class EventDispatchException extends RuntimeException {
    public EventDispatchException(String message, Throwable cause) {
        super(message, cause);
    }
}