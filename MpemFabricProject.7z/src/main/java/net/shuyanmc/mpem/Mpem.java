package net.shuyanmc.mpem;

import net.fabricmc.api.ModInitializer;

public class Mpem implements ModInitializer {

    @Override
    public void onInitialize() {
        new MpemMod();
    }
}
